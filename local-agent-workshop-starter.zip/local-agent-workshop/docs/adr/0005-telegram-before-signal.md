# ADR 5: Telegram Before Signal

Status: Proposed

Decision details to be expanded.
