# ADR 4: Review Cards As Approval Unit

Status: Proposed

Decision details to be expanded.
