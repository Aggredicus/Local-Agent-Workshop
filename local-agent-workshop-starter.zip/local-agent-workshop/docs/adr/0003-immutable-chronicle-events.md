# ADR 3: Immutable Chronicle Events

Status: Proposed

Decision details to be expanded.
