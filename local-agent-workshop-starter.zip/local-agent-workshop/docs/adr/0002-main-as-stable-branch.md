# ADR 2: Main As Stable Branch

Status: Proposed

Decision details to be expanded.
