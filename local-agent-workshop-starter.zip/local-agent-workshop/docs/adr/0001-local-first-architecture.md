# ADR 1: Local First Architecture

Status: Proposed

Decision details to be expanded.
