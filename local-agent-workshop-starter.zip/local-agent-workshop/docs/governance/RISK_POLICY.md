# Risk Policy

Autonomous agents may prepare sensitive work, but may not activate sensitive consequences without approval.
