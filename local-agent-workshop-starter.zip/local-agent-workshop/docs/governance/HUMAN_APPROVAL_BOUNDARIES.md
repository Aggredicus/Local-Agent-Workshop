# Human Approval Boundaries

Approval is required before protected branch merges, production deploys, live credential use, payment live effects, destructive actions, customer data access, secret rotation, public release, or irreversible migration.
