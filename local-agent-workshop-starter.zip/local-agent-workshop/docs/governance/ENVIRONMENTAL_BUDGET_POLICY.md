# Environmental and Budget Policy

Track wall time, model use, repeated failures, test runs, context size, estimated energy, and budget limits.
