# Autonomous Agent Policy

Agents may run for extended durations if work is checkpointed, branch-isolated, verified, resumable, and paused at approval boundaries.
