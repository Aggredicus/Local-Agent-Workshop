# Branch Policy

Protected branches: `main`, `develop`, `release/*`, `rc/*`. Agent work should happen on `agent/*` or other allowed non-protected branches.
