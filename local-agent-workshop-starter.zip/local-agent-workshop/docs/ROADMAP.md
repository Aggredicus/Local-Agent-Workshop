# Roadmap

- v0.1: CLI + Markdown review loop
- v0.2: Branch-aware sandbox runner
- v0.3: Repo graph + risk scoring
- v0.4: Resumable grind engine
- v0.5: Local dashboard
- v0.6: Telegram/Signal escalation
- v1.0: Stable Local Agent Workshop
