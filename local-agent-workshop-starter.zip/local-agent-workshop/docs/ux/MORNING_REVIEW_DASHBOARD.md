# Morning Review Dashboard

Show completed work, failed checks, pending decisions, risk items, and next actions.
