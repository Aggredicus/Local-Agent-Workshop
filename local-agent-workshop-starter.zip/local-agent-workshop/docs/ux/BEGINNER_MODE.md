# Beginner Mode

Primary actions: Start Work, Review Changes, Approve, Reject, Modify, Resume, Pause.
