# UX Spec

Support beginner and advanced modes. Beginner mode shows clear decisions. Advanced mode exposes branches, diffs, risks, graph, events, and release controls.
