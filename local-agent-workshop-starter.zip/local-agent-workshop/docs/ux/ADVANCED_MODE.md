# Advanced Mode

Expose run state, branch state, diffs, events, graph, risk scoring, CI matrix, budget, escalation, and release controls.
