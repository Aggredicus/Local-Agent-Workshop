# Review Workflow

Every patch should answer what changed, why, what passed, what failed, what risks remain, what decision is needed, and what happens next.
