# Escalation Policy

Escalation is quiet by default. Notify only when human judgment unlocks progress or prevents risk. Never send secrets.
