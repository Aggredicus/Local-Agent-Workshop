# Release Protocol

Flow: `agent/*` or `feature/*` → `develop` → `release/vX.Y.Z` or `rc/vX.Y.Z` → `main`.
