# Grind Protocol

Read `me.md`, load branch policy, select a task, use an isolated branch/worktree, perform scoped work, verify, write events, generate a review card, then continue/pause/escalate/stop.
