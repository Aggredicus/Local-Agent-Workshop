# Checkpoint and Resume Protocol

Checkpoints include run ID, task ID, branch, worktree, status, files changed, tests run, pending decisions, next safe action, and resume command.
