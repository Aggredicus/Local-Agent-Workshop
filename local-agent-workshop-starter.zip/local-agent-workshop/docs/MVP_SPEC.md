# MVP Spec

v0.1 must initialize repo structure, read branch policy, create Chronicle events, generate review cards, generate a morning report, run placeholder verification scripts, and support approve/reject/modify/resume concepts.
