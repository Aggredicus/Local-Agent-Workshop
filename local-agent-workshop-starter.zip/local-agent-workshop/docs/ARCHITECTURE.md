# Architecture

Subsystems:

1. CLI command layer: `workshop`
2. Branch policy engine
3. Sandbox runner
4. Grind loop
5. Chronicle event logger
6. Review card generator
7. Repo graph builder
8. Verification runner
9. Risk classifier
10. Escalation bridge
11. Budget/environmental tracker
12. Future local dashboard
