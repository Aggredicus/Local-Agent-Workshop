# Vision

Local Agent Workshop helps developers own the code-making process itself through local-first, reviewable, low-waste agentic development.
