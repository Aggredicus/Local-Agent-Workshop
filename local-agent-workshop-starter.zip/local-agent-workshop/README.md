# Local Agent Workshop

**Local Agent Workshop** is a local-first, human-governed autonomous software development workspace for long-running LLM-assisted coding, reviewable patches, branch-aware automation, Chronicle event logs, repo graphs, and clear human approval at risk boundaries.

- Repository: `local-agent-workshop`
- Product: **Local Agent Workshop**
- CLI command: `workshop`

## Core loop

```text
repo → task selection → isolated branch/worktree → work → verify → review card → human decision → resume
```

## Instruction hierarchy

```text
AGENTS.md / CLAUDE.md / CODEX.md / Cursor rules
  ↓
me.md
  ↓
docs/, schemas/, skills/, workflows/, plan/, scripts/
  ↓
runtime artifacts: chronicle/, reviews/, reports/, repo_graph/, .grind/
```

Start by reading `me.md`.
