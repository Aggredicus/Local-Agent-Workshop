"""Local Agent Workshop package."""
