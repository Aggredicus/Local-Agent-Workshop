from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
BRANCH_POLICY_PATH = ROOT / ".branch-policy.yaml"
