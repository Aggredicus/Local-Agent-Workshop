# CODEX.md

Canonical instructions live in `./me.md`.

Read `./me.md` before making changes. This file is a thin pointer for Codex-style agents; it should not duplicate the full project policy.

## Reminders

- Do not merge into protected branches without explicit human approval.
- Prefer isolated `agent/*` branches for autonomous work.
- Produce review cards for meaningful changes.
- Write Chronicle events for meaningful actions.
- Verify claims with scripts or documented evidence.
