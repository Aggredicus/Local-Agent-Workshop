# me.md — Canonical Instruction Spine

This file is the canonical instruction spine for **Local Agent Workshop**.

All tool adapter files such as `AGENTS.md`, `CLAUDE.md`, `CODEX.md`, and Cursor rules must point here instead of duplicating the full policy.

## Product identity

- Product name: **Local Agent Workshop**
- Repository name: `local-agent-workshop`
- CLI command: `workshop`

## Golden rule

```text
AGENTS.md / CLAUDE.md / CODEX.md / Cursor rules
  ↓
me.md
  ↓
docs/, schemas/, skills/, workflows/, plan/, scripts/
  ↓
chronicle/, reviews/, reports/, repo_graph/, .grind/
```

## Operating principles

1. Work locally first whenever practical.
2. Use branch-aware automation.
3. Never merge into protected branches without explicit human approval.
4. Produce reviewable patches, not silent production mutations.
5. Long-running grind is allowed, but it must be checkpointed and resumable.
6. Sensitive work is allowed in safe forms, but live effects require approval.
7. Every meaningful action should leave a Chronicle event.
8. Agents should stay quiet unless human judgment is truly required.
9. The workshop may improve itself only through reviewable proposals.

## Required reading map

- Branch model: `docs/governance/BRANCH_POLICY.md` and `.branch-policy.yaml`
- Risk gates: `docs/governance/RISK_POLICY.md`
- Human boundaries: `docs/governance/HUMAN_APPROVAL_BOUNDARIES.md`
- Grind: `docs/protocols/GRIND_PROTOCOL.md`
- Resume: `docs/protocols/CHECKPOINT_RESUME_PROTOCOL.md`
- Review: `docs/protocols/REVIEW_WORKFLOW.md`
- Escalation: `docs/protocols/ESCALATION_POLICY.md`
- Schemas: `schemas/`
- Skills: `skills/INDEX.md`
- Workflows: `workflows/INDEX.md`

## Branch model

```text
main          stable/client-safe/released code
develop       reviewed integration
experimental  sandbox and lab work
agent/*       autonomous work branches
release/*     QA/release candidates
```

## Verification commands

Use scripts under `scripts/` when available:

```sh
scripts/verify.sh
scripts/test-fast.sh
scripts/test-full.sh
scripts/security-scan.sh
scripts/release-check.sh
```
