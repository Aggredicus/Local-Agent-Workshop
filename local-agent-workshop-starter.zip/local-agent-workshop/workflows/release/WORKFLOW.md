# Workflow: /release

Entry command: `workshop release`

Read `me.md` and relevant docs before execution.
