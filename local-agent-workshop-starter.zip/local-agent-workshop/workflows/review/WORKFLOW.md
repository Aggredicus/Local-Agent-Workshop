# Workflow: /review

Entry command: `workshop review`

Read `me.md` and relevant docs before execution.
