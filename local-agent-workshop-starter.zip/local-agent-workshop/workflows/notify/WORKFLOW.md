# Workflow: /notify

Entry command: `workshop notify`

Read `me.md` and relevant docs before execution.
