# Workflow: /reject

Entry command: `workshop reject`

Read `me.md` and relevant docs before execution.
