# Workflows Index

- /status
- /grind
- /review
- /approve
- /reject
- /modify
- /resume
- /pause
- /graph
- /release
- /notify
