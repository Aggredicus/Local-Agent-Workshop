# Workflow: /modify

Entry command: `workshop modify`

Read `me.md` and relevant docs before execution.
