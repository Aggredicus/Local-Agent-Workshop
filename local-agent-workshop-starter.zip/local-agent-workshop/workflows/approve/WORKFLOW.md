# Workflow: /approve

Entry command: `workshop approve`

Read `me.md` and relevant docs before execution.
