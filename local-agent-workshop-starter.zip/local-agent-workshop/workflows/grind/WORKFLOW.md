# Workflow: /grind

Entry command: `workshop grind`

Read `me.md` and relevant docs before execution.
