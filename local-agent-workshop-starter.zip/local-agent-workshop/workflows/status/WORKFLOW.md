# Workflow: /status

Entry command: `workshop status`

Read `me.md` and relevant docs before execution.
