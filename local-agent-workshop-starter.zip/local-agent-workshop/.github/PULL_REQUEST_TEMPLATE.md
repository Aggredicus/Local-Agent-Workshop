## Summary

## Risk level

- [ ] Low
- [ ] Medium
- [ ] High
- [ ] Requires explicit human approval

## Verification

Commands run:

```sh

```

## Checklist

- [ ] I read `me.md`.
- [ ] I followed the branch policy.
- [ ] I did not commit secrets.
- [ ] I included verification evidence.
