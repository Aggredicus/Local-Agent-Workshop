# Security Policy

- Never commit secrets.
- Never print secrets into logs.
- Never send secrets through escalation channels.
- Do not use live credentials without explicit human approval.
- Use `.env.example` for configuration examples.

Agents may prepare sensitive work in isolated branches, mocks, simulations, and tests. Agents must pause before live effects.
