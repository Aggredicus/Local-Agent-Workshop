# Contributing

Use branch-aware, review-first development. Do not commit directly to protected branches.

Allowed branch prefixes include `agent/*`, `feature/*`, `fix/*`, `hotfix/*`, `refactor/*`, `docs/*`, `test/*`, `chore/*`, `spike/*`, `release/*`, and `rc/*`.
