# Skills Index

- design-first
- tdd
- verify
- code-review
- security-review
- repo-graph
- grind
- release
- ci-cd
- escalation
