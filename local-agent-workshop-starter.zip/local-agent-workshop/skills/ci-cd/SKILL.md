# Skill: ci-cd

Read `me.md`, follow branch policy, verify claims, and pause at approval boundaries.
