# Local Agent Workshop — Design-First Starting Point

Generated with the `/design-first` skill.

## Main report

Open:

```text
reports/design-first/design-first-0001-project-start.html
```

## Supporting artifacts

```text
chronicle/events/event-design-first-0001.json
reviews/pending/review-design-first-0001.json
```

## Recommended next action

import starter repo, protect branches, then implement workshop init
